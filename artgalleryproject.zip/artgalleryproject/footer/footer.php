<!-- Footer -->
<footer id="footer">
   <div class="container">
      <ul class="icons">
         <li><a href="#" class="icon fa-twitter"><span class="label">Twitter</span></a></li>
         <li><a href="#" class="icon fa-facebook"><span class="label">Facebook</span></a></li>
         <li><a href="#" class="icon fa-instagram"><span class="label">Instagram</span></a></li>
         <li><a href="#" class="icon fa-envelope-o"><span class="label">Email</span></a></li>
      </ul>
   </div>
   <div class="copyright">
      <div class="footer text-center">Design & Develop By Mayuri K | Visit : www.mayurik.com</div>
      &copy; MayuriK Artwork Online Studio.All rights reserved.
   </div>
</footer>
<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/jquery.scrollex.min.js"></script>
<script src="assets/js/skel.min.js"></script>
<script src="assets/js/util.js"></script>
<script src="assets/js/main.js"></script>
<script src="assets/js/bootstrap.js"></script>
</body>
</html>